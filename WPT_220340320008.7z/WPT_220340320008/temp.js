const express = require('express');
const app = express();
const url="";
let bookUpdate={
    host:'localhost',
    user:'root',
    pasword:'cdac',
    database:'QuestionBook',
    port:3306

}
let mysql=require('mysql2');
let conn=mysql.createConnection(bookUpdate);

app.use(express.static('abc'));
app.get('/blurEvent',(req,resp)=>{
    let input=req.query.bookId;
    let output={status:false,bookDetails:{bookid:0,bookName:"",price:0}}
    conn.query('select bookId,bookName,price from book where bookId=?',[input],
    (err,row)=>{
    if(err){
        console.log("error occured "+err);
    }else{
        if(row.length>0){
            output.status=true;
            output.bookdetails=row[0];
        }
    }
    });
    
    res.send(output);
});


app.get('/updateEvent',(req,resp)=>{
    let input=req.query.bookId;
    let output={status:false,bookDetails:{bookid:0,bookName:"",price:0}}
    conn.query('update book set bookName=?, price=? where bookid=?',[input.bookId,input.bookName,input.price],
    (err,row)=>{
    if(err){
        console.log("error in the file "+err);
    }else{
        if(row.affectedRows>0){
            output.status=true;
            output.bookdetails=row[0];
        }
    }
    });
    
    res.send(output);
});


app.listen(8081, function () {
    console.log("server listening at port 8081...");
});